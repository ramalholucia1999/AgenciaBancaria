#include "ContaInvestimento.h"

ContaInvestimento::ContaInvestimento()
{
}

ContaInvestimento::ContaInvestimento(string agencia, string numConta, string proprietario, float saldo, float limite, TipoInvestimento tipoInvestimento, float saldoInvestimento) : ContaCorrente(agencia, numConta, proprietario, saldo, limite), Investimento(tipoInvestimento, saldoInvestimento){
	setTipoInvestimento(tipoInvestimento);
	setSaldoInvestimento(saldoInvestimento);
}

ContaInvestimento::~ContaInvestimento()
{
}

void ContaInvestimento::imprimirExtrato(){
	
	ContaCorrente::imprimirExtrato();
	cout << "Tipo de investimento: " << tipoInvestimento << endl;
	cout << "Saldo investido: " << saldoInvestimento << endl;
}

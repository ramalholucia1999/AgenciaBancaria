#include <iostream>
#include <locale>

#include "ContaCorrente.h"
#include "ContaPoupanca.h"
#include "ContaInvestimento.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

using namespace std;

void cadastrarConta(Conta *conta){
	
	cout << "Entre com a ag�ncia da conta: ";
	string agencia;
	getline(cin, agencia);
	conta->setAgencia(agencia);
	cin.clear();
	fflush(stdin);
	
	cout << "Entre com o n�mero da conta: ";
	string numConta;
	getline(cin, numConta);
	conta->setNumConta(numConta);
	cin.clear();
	fflush(stdin);
	
	cout << "Entre com o propriet�rio da conta: ";
	string proprietario;
	getline(cin, proprietario);
	conta->setProprietario(proprietario);
	cin.clear();
	fflush(stdin);
	
	cout << "Entre com o saldo da conta: ";
	float saldo;
	cin >> saldo;
	conta->setSaldo(saldo);
	cin.clear();
	fflush(stdin);
	
}

void cadastrarContaPoupanca(ContaPoupanca *cp){
	
	cadastrarConta(cp);
	int opcao;
	do{
		cout << "Entre com o m�s de anivers�rio" << endl;
		cout << "1 - Janeiro" << endl;
		cout << "2 - Fevereiro" << endl;
		cout << "3 - Mar�o" << endl;
		cout << "4 - Abril" << endl;
		cout << "5 - Maio" << endl;
		cout << "6 - Junho" << endl;
		cout << "7 - Julho" << endl;
		cout << "8 - Agosto" << endl;
		cout << "9 - Setembro" << endl;
		cout << "10 - Outubro" << endl;
		cout << "11 - Novembro" << endl;
		cout << "12 - Dezembro" << endl;
		cout << "Entre com a op��o: ";
		cin >> opcao;
		
		if(opcao < 1 || opcao > 12){
			cout << "Op��o inv�lida! Favor entrar com uma op��o do menu" << endl << endl;
		}

	}while(opcao < 1 || opcao > 12);
	
	MesAniversario mes;
	
	switch(opcao){
		case 1:
			mes = JANEIRO;
			break;
			
		case 2:
			mes = FEVEREIRO;
			break;
			
		case 3:
			mes = MARCO;
			break;
			
		case 4:
			mes = ABRIL;
			break;
			
		case 5:
			mes = MAIO;	
			break;
			
		case 6:
			mes = JUNHO;
			break;
			
		case 7:
			mes = JULHO;
			break;
			
		case 8:
			mes = AGOSTO;
			break;
		
		case 9:
			mes = SETEMBRO;
			break;
			
		case 10:
			mes = OUTUBRO;
			break;
			
		case 11:
			mes = NOVEMBRO;
			break;
			
		case 12:
			mes = DEZEMBRO;
			break;	
	}
	
	cp->setMes(mes);
	cout << "Conta Poupan�a criada com sucesso!" << endl << endl;
}

void cadastrarContaCorrente(ContaCorrente *contaCorrente){
	
	cadastrarConta(contaCorrente);
	
	cout << "Entre com o limite da conta: ";
	float limite;
	cin >> limite;
	contaCorrente->setLimite(limite);
	cin.clear();
	fflush(stdin);
	
	cout << "Conta Corrente criada com sucesso!" << endl << endl;
	
}

void cadastrarContaInvestimento(ContaInvestimento *contaInvestimento){
	
	cadastrarContaCorrente(contaInvestimento);
	
	int opcao;
	
	do{
		cout << "Entre com o tipo de investimento: " << endl;
		cout << "1 - CDB" << endl;
		cout << "2 - TESOURO DIRETO" << endl;
		cout << "3 - FUNDO DE A��ES" << endl;
		cout << "4 - FUNDO IMOBILI�RIO" << endl;
		cout << "Entre com a op��o: ";
		cin >> opcao;
		cin.clear();
		fflush(stdin);
		cout << endl;
		
		if(opcao < 1 || opcao > 4){	
			cout << "Op��o inv�lida! Favor entrar com uma op��o do menu" << endl << endl;
		}
	}while(opcao < 1 || opcao > 4);
	
	TipoInvestimento tipo;
	
	switch(opcao){
		case 1:
			tipo = CDB;
			break;
			
		case 2:
			tipo = TESOURO;
			break;
		
		case 3:
			tipo = ACAO;
			break;
			
		case 4:
			tipo = IMOBILIARIO;
			break;
	}
	
	contaInvestimento->setTipoInvestimento(tipo);
	
	cout << "Entre com o saldo do investimento: ";
	float saldoInvestimento;
	cin >> saldoInvestimento;
	contaInvestimento->setSaldoInvestimento(saldoInvestimento);
	cin.clear();
	fflush(stdin); 
}

void cadastrarConta(Conta *listConta[100], int quantConta){
	
	int opcao;
	
	do{
		cout << "			Cadastro de conta" << endl << endl;
		cout << "1 - Conta Corrente" << endl;
		cout << "2 - Conta Poupan�a" << endl;
		cout << "3 - Conta Investimento" << endl << endl;
	
		cout << "Entre com a op��o: ";
		cin >> opcao;
		cin.clear();
		fflush(stdin);
		cout << endl;
		
		if(opcao < 1 || opcao > 3){
			cout << "Op��o inv�lida! Favor entrar com uma op��o do menu" << endl << endl;
		}
		
		switch(opcao){
			case 1:{
				cout << "			Cadastro de Conta Corrente" << endl << endl;
				ContaCorrente *cc = new ContaCorrente();
				cadastrarContaCorrente(cc);
				cout << endl;
				listConta[quantConta] = cc;
				break;
			}
		
			case 2:{
				cout << "			Cadastro de Conta Poupan�a" << endl << endl;
				ContaPoupanca *cp = new ContaPoupanca();
				cadastrarContaPoupanca(cp);
				cout << endl;
				listConta[quantConta] = cp;
				break;
			}
			case 3:
				cout << "			Cadastro de Conta Investimento" << endl << endl;
				ContaInvestimento *ci = new ContaInvestimento();
				cadastrarContaInvestimento(ci);
				listConta[quantConta] = ci;
				break;
		}
	}while(opcao < 1 || opcao > 3);
}

Conta * buscarConta(Conta *listConta[100], int quantConta){
	
	cout << "Entre com a ag�ncia da conta: ";
	string agencia;
	getline(cin, agencia);
	cin.clear();
	fflush(stdin);
	cout << endl;
	
	cout << "Entre com o n�mero da conta: ";
	string numConta;
	getline(cin, numConta);
	cin.clear();
	fflush(stdin);
	cout << endl;
	
	for(int i = 0; i < quantConta; i++){
		
		Conta *conta = listConta[i];
		if((agencia == conta->getAgencia()) && (numConta == conta->getNumConta())){
			return conta;
		}
	}
	return NULL;
}

void extratoConta(Conta *listConta[100], int quantConta){
	Conta *conta = buscarConta(listConta, quantConta);
	
	if(conta != NULL){
		conta->imprimirExtrato();
		cout << endl;
		
		if(dynamic_cast<ContaInvestimento*>(conta)){
			cout << "Conta Investimento" << endl;
		}else if(dynamic_cast<ContaPoupanca*>(conta)){
			cout << "Conta Poupan�a" << endl;
		}else{
			cout << "Conta Corrente" << endl;
		}
		
	}else{
		cout << "Conta n�o encontrada" << endl;
	}
}

void depositarValor(Conta *listConta[100], int quantConta){
	
	Conta *conta = buscarConta(listConta, quantConta);
	
	if(conta != NULL){
		cout << "Entre com o valor a ser depositado: ";
		float valor;
		cin >> valor;
		cin.clear();
		fflush(stdin);
		cout << endl;
		
		if(conta->depositar(valor)){		
			cout << "Valor " << valor << " depositado com sucesso na conta de " << conta->getProprietario() << endl;
		}
		else{
			cout << "Valor inv�lido para depositar";
		}
	}else{
		cout << "Conta n�o encontrada" << endl;
	}
	
}

void sacarValor(Conta *listConta[100], int quantConta){
	Conta *conta = buscarConta(listConta, quantConta);
	
	if(conta != NULL){
		cout << "Entre com o valor a ser sacado: ";
		float valor;
		cin >> valor;
		cin.clear();
		fflush(stdin);
		cout << endl;
		
		if(conta->sacar(valor)){		
			cout << "Valor " << valor << " sacado com sucesso na conta de " << conta->getProprietario() << endl;
		}
		else{
			cout << "Valor inv�lido para sacar" << endl << endl;
		}
	}else{
		cout << "Conta n�o encontrada" << endl;
	}
}

int main(int argc, char** argv) {
	
	setlocale(LC_ALL, "");
	system("chcp 1252 > nul");
	
	Conta *listConta[100];
	int quantConta = 0;
	
	int opcao;
	
	do{
	
		do{
			cout << "			Cadastro de Contas" << endl << endl;
			cout << "1 - Cadastrar conta" << endl;
			cout << "2 - Extrato de conta" << endl;
			cout << "3 - Depositar valor" << endl;
			cout << "4 - Sacar valor" << endl;
			cout << "5 - Sair" << endl;
	
			cout << "Entre com a op��o: ";
			cin >> opcao;
			cin.clear();
			fflush(stdin);
			cout << endl;
			
			if(opcao < 1 || opcao > 5){
				cout << "Op��o inv�lida! Favor entrar com uma op��o do menu" << endl << endl;
			}
			
		}while(opcao < 1 || opcao > 5);
		
		switch(opcao){
			case 1:
				cadastrarConta(listConta, quantConta);
				quantConta += 1;
				break;
			case 2:
				if(quantConta > 0){
					extratoConta(listConta, quantConta);
				}else{
					cout << "Nunhuma conta cadastrada" << endl << endl;
				}
				break;
			case 3:
				if(quantConta > 0){
					depositarValor(listConta, quantConta);
				}else{
					cout << "Nunhuma conta cadastrada" << endl << endl;
				}
				break;
			case 4:
				if(quantConta > 0){
					sacarValor(listConta, quantConta);
				}else{
					cout << "Nunhuma conta cadastrada" << endl << endl;
				}
				break;
			case 5:
				cout << "Obrigado por utilizar o nosso sistema" << endl << endl;
				break;
		}
		
	}while(opcao != 5);
	
	return 0;
}
